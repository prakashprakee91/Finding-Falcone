import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanetvehiclesComponent } from './planetvehicles.component';

describe('PlanetvehiclesComponent', () => {
  let component: PlanetvehiclesComponent;
  let fixture: ComponentFixture<PlanetvehiclesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanetvehiclesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanetvehiclesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
